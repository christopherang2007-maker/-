// Vercel Serverless Function：仅返回浏览器 Supabase 客户端需要的公开配置。
// 绝不可在此处返回 SUPABASE_SERVICE_ROLE_KEY 或任何 secret key。
export default function handler(request, response) {
  const url = process.env.SUPABASE_URL;
  const anonKey = process.env.SUPABASE_ANON_KEY;

  if (!url || !anonKey) {
    return response.status(500).json({ error: 'Supabase environment variables are not configured.' });
  }

  response.setHeader('Cache-Control', 'no-store');
  return response.status(200).json({ url, anonKey });
}
